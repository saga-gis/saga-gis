/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

//---------------------------------------------------------


///////////////////////////////////////////////////////////
//														 //
//														 //
//														 //
///////////////////////////////////////////////////////////

//---------------------------------------------------------
#include "rdb2_export.h"

#include <algorithm> // std::find
#include <array>
#include <vector>
#include <sstream>
#include <functional> //reference wrapper

#include <riegl/rdb.hpp>
#include <riegl/rdb/factory.hpp>

#include "rapidjson/document.h"
#include "rapidjson/pointer.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/writer.h"
#include "rapidjson/prettywriter.h"

///////////////////////////////////////////////////////////
//														 //
//														 //
//														 //
///////////////////////////////////////////////////////////


//---------------------------------------------------------
#define	ADD_FIELD(id, var, name, type)	if( Parameters(id)->asBool() ) { iField[var] = nFields++; pPoints->Add_Field(name, type); } else { iField[var] = -1; }

using namespace riegl::rdb;
///////////////////////////////////////////////////////////
//														 //
//														 //
//														 //
///////////////////////////////////////////////////////////

//---------------------------------------------------------
CRDB2_Export::CRDB2_Export(void)
{

	CSG_Parameter	*pNodeAttr;

	//-----------------------------------------------------
	// 1. Info...

	Set_Name		(_TL("Export RDB2 Files"));

	Set_Author		(SG_T("R.Gschweicher (c) 2016, Riegl GmbH"));

	CSG_String		Description(_TW(
		"Export a pointcloud to Riegl RDB 2 format. "
		"This is a work in progress."
	));

	Set_Description	(Description);

	//-----------------------------------------------------
	// 2. Parameters...
	pNodeAttr = Parameters.Add_PointCloud(
		NULL	, "POINTS"		, _TL("Point Cloud"),
		_TL("The point cloud to export."),
		PARAMETER_INPUT
	);

	Parameters.Add_Table_Field(
		pNodeAttr, "id"       , _TL("riegl.id"),
		_TL(""), true
	);
	Parameters.Add_Table_Field(
		pNodeAttr, "ts"    , _TL("riegl.timestamp"),
		_TL(""), true
	);
	Parameters.Add_Table_Field(
		pNodeAttr, "ampl"    , _TL("riegl.amplitude"),
		_TL(""), true
	);
	Parameters.Add_Table_Field(
		pNodeAttr, "refl"    , _TL("riegl.reflectance"),
		_TL(""), true
	);
	Parameters.Add_Table_Field(
		pNodeAttr, "dev"    , _TL("riegl.deviation"),
		_TL(""), true
	);
	Parameters.Add_Table_Field(
		pNodeAttr, "pw"    , _TL("riegl.pulse_width"),
		_TL(""), true
	);
	Parameters.Add_Table_Field(
		pNodeAttr, "t_idx"    , _TL("riegl.target_index"),
		_TL(""), true
	);
	Parameters.Add_Table_Field(
		pNodeAttr, "t_cnt"    , _TL("riegl.target_count"),
		_TL(""), true
	);
	Parameters.Add_Table_Field(
		pNodeAttr, "class"    , _TL("riegl.class"),
		_TL(""), true
	);
	Parameters.Add_Table_Field(
		pNodeAttr, "rgba"    , _TL("riegl.rgba"),
		_TL(""), true
	);

	Parameters.Add_FilePath(
		NULL, "FILE"		, _TL("Output File"),
		_TL("The RDB2 output file."),
		_TL("RDB2 Files (*.rdbx)|*.rdbx|All Files|*.*"),
		NULL, true
	);
	Parameters.Add_Value(
		NULL	, "update" , _TL("Check to update existing file"),
		_TL(""),
		PARAMETER_TYPE_Bool, false
	);
	Parameters.Add_Value(
		NULL, "epsg" , _TL("Export epsg geo-tag"),
		_TL(""),
		PARAMETER_TYPE_Bool, false
	);
}


///////////////////////////////////////////////////////////
//														 //
//														 //
//														 //
///////////////////////////////////////////////////////////
static const size_t BUFFER_SIZE = 100000;

template<std::size_t BufferSize, typename Query>
struct resize_and_bind_buffer_functor
{
	resize_and_bind_buffer_functor(Query &q) :
		query_(q)
	{}

	template<typename T>
	void operator()(int param_idx,
					const char *att, std::vector<T> &buffer,
					const riegl::rdb::pointcloud::DataType rdb_type)
	{
		if (param_idx > -1)
		{
			buffer.resize(BufferSize);
			query_.get().bind(att, rdb_type, buffer.data());
		}
	}

private:
	std::reference_wrapper<Query> query_;
};
template<std::size_t BufferSize, typename Query>
resize_and_bind_buffer_functor<BufferSize, Query> make_resize_and_bind_buffer(Query &query)
{
	return resize_and_bind_buffer_functor<BufferSize, Query>(query);
}

struct attr_indizes {
	int id;
	int ts;
	int ampl;
	int refl;
	int dev;
	int pw;
	int t_idx;
	int t_cnt;
	int r_class;
	int rgba;
};

struct riegl_buffers {
	std::vector< std::array<double, 3> >  xyz;
	std::vector<uint64_t>                 id;
	std::vector<double>                   ts;
	std::vector<float>                    ampl;
	std::vector<float>                    refl;
	std::vector<int16_t>                  dev;
	std::vector<float>                    pw;
	std::vector<uint8_t>                  t_idx;
	std::vector<uint8_t>                  t_cnt;
	std::vector<uint16_t>                 r_class;
	std::vector< std::array<uint8_t, 4> > rgba;
};
template<typename T>
void prepare_rdb_query(T &query, attr_indizes &idx, riegl_buffers &buffer)
{
	auto resize_and_bind_buffer =  make_resize_and_bind_buffer<BUFFER_SIZE>(query);
	resize_and_bind_buffer(idx.id,      "riegl.id",           buffer.id,      riegl::rdb::pointcloud::UINT64);
	resize_and_bind_buffer(idx.ts,      "riegl.timestamp",    buffer.ts,      riegl::rdb::pointcloud::DOUBLE);
	resize_and_bind_buffer(idx.ampl,    "riegl.amplitude",    buffer.ampl,    riegl::rdb::pointcloud::SINGLE);
	resize_and_bind_buffer(idx.refl,    "riegl.reflectance",  buffer.refl,    riegl::rdb::pointcloud::SINGLE);
	resize_and_bind_buffer(idx.dev,     "riegl.deviation",    buffer.dev,     riegl::rdb::pointcloud::INT16);
	resize_and_bind_buffer(idx.pw,      "riegl.pulse_width",  buffer.pw,      riegl::rdb::pointcloud::SINGLE);
	resize_and_bind_buffer(idx.t_idx,   "riegl.target_index", buffer.t_idx,   riegl::rdb::pointcloud::UINT8);
	resize_and_bind_buffer(idx.t_cnt,   "riegl.target_count", buffer.t_cnt,   riegl::rdb::pointcloud::UINT8);
	resize_and_bind_buffer(idx.r_class, "riegl.class",        buffer.r_class, riegl::rdb::pointcloud::UINT16);
	resize_and_bind_buffer(idx.rgba,    "riegl.rgba",         buffer.rgba,    riegl::rdb::pointcloud::UINT8);
}

//---------------------------------------------------------
bool CRDB2_Export::On_Execute(void)
{
	struct factory_mode
	{
		inline factory_mode() {riegl::rdb::factoryModeOn();}
		inline ~factory_mode() {riegl::rdb::factoryModeOff();}
	} fm;

	SG_UI_Msg_Add(CSG_String::Format(_TL("CRDB2 Export Execute")), true);

	CSG_PointCloud *pPoints;
	//-----------------------------------------------------

	pPoints          = Parameters("POINTS")->asPointCloud();
	attr_indizes idx;
	idx.id       = Parameters("id")->asInt();
	idx.ts       = Parameters("ts")->asInt();
	idx.ampl     = Parameters("ampl")->asInt();
	idx.refl     = Parameters("refl")->asInt();
	idx.dev      = Parameters("dev")->asInt();
	idx.pw       = Parameters("pw")->asInt();
	idx.t_idx    = Parameters("t_idx")->asInt();
	idx.t_cnt    = Parameters("t_cnt")->asInt();
	idx.r_class  = Parameters("class")->asInt();
	idx.rgba     = Parameters("rgba")->asInt();

	CSG_String fName = Parameters("FILE")->asString();

	bool rdbx_update = Parameters("update")->asBool();
	bool param_epsg  = Parameters("epsg")->asBool();

	// define software_name for rdb transactions
	std::string software_name = "saga-gis rdb2 export";

	SG_UI_Msg_Add(CSG_String::Format(_TL("create rdb context")), true);
	// start rdb transaction
	riegl::rdb::Context context;
	riegl::rdb::Pointcloud rdb(context);
	// step1
	if (rdbx_update)
	{
		try {
			SG_UI_Msg_Add(CSG_String::Format(_TL("open rdb file")), true);
			pointcloud::OpenSettings settings(context);
			rdb.open(fName.b_str(), settings);
			if (rdb.pointAttribute().primaryAttributeName() != "riegl.xyz")
				throw(std::runtime_error("rdb file primary attribute is not 'riegl.xyz'"));
		} catch (std::exception &e)
		{
			std::ostringstream ss;
			ss << "Unable to open RDB2 file! Exception: " << e.what();
			SG_UI_Msg_Add_Error(ss.str().c_str());
			return false;
		}
		catch(...) {
			SG_UI_Msg_Add_Error(CSG_String::Format(_TL("Unknown RDB2 open exception!")));
			return false;
		}
	}
	else
	{
		try {
			SG_UI_Msg_Add(CSG_String::Format(_TL("create rdb file")), true);
			pointcloud::CreateSettings settings(context);
			pointcloud::PointAttribute riegl_attr = rdb.pointAttribute()
					.getDefault(context, "riegl.xyz");
			settings.primaryAttribute = riegl_attr;
			rdb.create(fName.b_str(), settings);
		} catch (std::exception &e)
		{
			std::ostringstream ss;
			ss << "Unable to create RDB2 file! Exception: " << e.what();
			SG_UI_Msg_Add_Error(ss.str().c_str());
			return false;
		}
		catch(...) {
			SG_UI_Msg_Add_Error(CSG_String::Format(_TL("Unknown RDB2 creation exception!")));
			return false;
		}
	}

	SG_UI_Msg_Add(CSG_String::Format(_TL("create rdb transaction")), true);
	std::string transaction_title;
	if (rdbx_update)
		transaction_title = "Update";
	else
		transaction_title = "Initialization";

	// Before we can modify the database, we must start a transaction
	riegl::rdb::pointcloud::TransactionScope transaction(rdb,
		transaction_title.c_str(), // transaction title
		software_name.c_str()      // software name
	);
	// step2
	try {
		auto assign_attribute = [&context, &rdb] (int att_idx, const std::string &riegl_attribute)
		{
			if (att_idx > -1)
			{
				// check if attribute is already present (only on update case)
				if(rdb.pointAttribute().exists(riegl_attribute))
					return;
				rdb.pointAttribute().add(riegl_attribute);
			}
		};
		// create all other attributes
		assign_attribute(idx.ts,      "riegl.timestamp");
		assign_attribute(idx.ampl,    "riegl.amplitude");
		assign_attribute(idx.refl,    "riegl.reflectance");
		assign_attribute(idx.dev,     "riegl.deviation");
		assign_attribute(idx.pw,      "riegl.pulse_width");
		assign_attribute(idx.t_idx,   "riegl.target_index");
		assign_attribute(idx.t_cnt,   "riegl.target_count");
		assign_attribute(idx.r_class, "riegl.class");
		assign_attribute(idx.rgba,    "riegl.rgba");

		SG_UI_Msg_Add(CSG_String::Format(_TL("commit rdb transaction")), true);
		//transaction.commit();
	} catch (std::exception &e)
	{
		std::ostringstream ss;
		ss << "Unable to create RDB2 attributes! Exception: " << e.what();
		SG_UI_Msg_Add_Error(ss.str().c_str());
		return false;
	}
	catch(...) {
		SG_UI_Msg_Add_Error(CSG_String::Format(_TL("Unknown RDB2 attribute creation exception!")));
		return false;
	}
	// write meta information
	try {
		if (param_epsg)
		{
			SG_UI_Msg_Add(CSG_String::Format(_TL("create rdb transaction for meta information")), true);
			// Before we can modify the database, we must start a transaction
			//riegl::rdb::pointcloud::TransactionScope transaction(rdb,
			//	"Set meta information",      // transaction title
			//	software_name.c_str()  // software name
			//);
			riegl::rdb::pointcloud::MetaData meta = rdb.metaData();
			std::string geo_tag_name = "riegl.geo_tag";

			int epsg;
			epsg = pPoints->Get_Projection().Get_EPSG();
			const CSG_String wkt_tmp = pPoints->Get_Projection().Get_WKT();
			std::string wkt(wkt_tmp.b_str());
			rapidjson::Document d(rapidjson::kObjectType);
			rapidjson::Document::AllocatorType& allocator = d.GetAllocator();

			rapidjson::Value j_crs(rapidjson::kObjectType);
			j_crs.AddMember("epsg", epsg, allocator);
			rapidjson::Value j_wkt;
			j_wkt.SetString(wkt.c_str(), wkt.length());
			j_crs.AddMember("wkt", j_wkt, allocator);

			rapidjson::Value j_pose(rapidjson::kArrayType);
			{
				for (int i = 0; i < 4; i++)
				{
					rapidjson::Value j_pose_entry(rapidjson::kArrayType);
					j_pose_entry.PushBack(0, allocator);
					j_pose_entry.PushBack(0, allocator);
					j_pose_entry.PushBack(0, allocator);
					j_pose_entry.PushBack(0, allocator);
					j_pose_entry[i] = 1;
					j_pose.PushBack(j_pose_entry, allocator);
				}
			}

			d.AddMember("crs",  j_crs,  allocator);
			d.AddMember("pose",  j_pose,  allocator);

			// create string from json object
			rapidjson::StringBuffer buffer;
			//rapidjson::Writer <rapidjson::StringBuffer> writer(buffer);
			rapidjson::Writer<rapidjson::StringBuffer> writer(buffer);
			d.Accept(writer);

			// set created string as meta field
			meta.set(geo_tag_name, buffer.GetString());
			//transaction.commit();
		}
	} catch (std::exception &e)
	{
		std::ostringstream ss;
		ss << "Unable to create RDB2 meta information! Exception: " << e.what();
		SG_UI_Msg_Add_Error(ss.str().c_str());
		return false;
	}
	catch(...) {
		SG_UI_Msg_Add_Error(CSG_String::Format(_TL("Unknown RDB2 attribute creation exception!")));
		return false;
	}

	// step3
	try {
		SG_UI_Msg_Add(CSG_String::Format(_TL("start RDB2 transaction for writing points")), true);

		//std::string transaction_title;
		//if (rdbx_update)
		//	transaction_title = "Update points";
		//else
		//	transaction_title = "Insert points";

		// Before we can modify the database, we must start a transaction
		//riegl::rdb::pointcloud::TransactionScope transaction(rdb,
		//	transaction_title.c_str(), // transaction title
		//	software_name.c_str()      // software name
		//);

		// Start new insert query and define buffers
		riegl::rdb::pointcloud::QueryInsert query_ins = rdb.insert();
		riegl::rdb::pointcloud::QueryUpdate query_upd = rdb.update();

		SG_UI_Msg_Add(CSG_String::Format(_TL("assign buffers")), true);
		// assign buffers for writing to rdbx
		riegl_buffers buffer;
		if (rdbx_update)
		{
			prepare_rdb_query(query_upd, idx, buffer);
		} else
		{
			buffer.xyz.resize(BUFFER_SIZE);
			query_ins.bind("riegl.xyz", riegl::rdb::pointcloud::DOUBLE, buffer.xyz.data());
			prepare_rdb_query(query_ins, idx, buffer);
		}


		SG_UI_Msg_Add(CSG_String::Format(_TL("export points")), true);
		double x,y,z;
		size_t i_buffer = 0;
		int i_points = 0;
		while (i_points < pPoints->Get_Count())
		{
			if (!rdbx_update)
			{
				x = pPoints->Get_X(i_points);
				y = pPoints->Get_Y(i_points);
				z = pPoints->Get_Z(i_points);
				buffer.xyz[i_buffer][0] = x;
				buffer.xyz[i_buffer][1] = y;
				buffer.xyz[i_buffer][2] = z;
			}
			if (idx.id > -1)
				buffer.id[i_buffer] = static_cast<uint64_t>(pPoints->Get_Value(i_points, idx.id));
			if (idx.ts> -1)
				buffer.ts[i_buffer] = static_cast<double>(pPoints->Get_Value(i_points, idx.ts));
			if (idx.ampl> -1)
				buffer.ampl[i_buffer] = static_cast<float>(pPoints->Get_Value(i_points, idx.ampl));
			if (idx.refl> -1)
				buffer.refl[i_buffer] = static_cast<float>(pPoints->Get_Value(i_points, idx.refl));
			if (idx.dev> -1)
				buffer.dev[i_buffer] = static_cast<int16_t>(pPoints->Get_Value(i_points, idx.dev));
			if (idx.pw> -1)
				buffer.pw[i_buffer] = static_cast<float>(pPoints->Get_Value(i_points, idx.pw));
			if (idx.t_idx> -1)
				buffer.t_idx[i_buffer] = static_cast<uint8_t>(pPoints->Get_Value(i_points, idx.t_idx));
			if (idx.t_cnt> -1)
				buffer.t_cnt[i_buffer] = static_cast<uint8_t>(pPoints->Get_Value(i_points, idx.t_cnt));
			if (idx.r_class> -1)
				buffer.r_class[i_buffer] = static_cast<uint16_t>(pPoints->Get_Value(i_points, idx.r_class));
			if (idx.rgba > -1)
			{
				int rgb = static_cast<int>(pPoints->Get_Value(i_points, idx.rgba));
				buffer.rgba[i_buffer][0] = SG_GET_R(rgb);
				buffer.rgba[i_buffer][1] = SG_GET_G(rgb);
				buffer.rgba[i_buffer][2] = SG_GET_B(rgb);
				buffer.rgba[i_buffer][3] = 0;
			}

			i_points++;
			i_buffer++;
			if (i_buffer >= BUFFER_SIZE)
			{
				// write buffers into RDB2 file
				if (rdbx_update)
					query_upd.next(i_buffer);
				else
					query_ins.next(i_buffer);
				i_buffer = 0;
				SG_UI_Process_Set_Progress(i_points, pPoints->Get_Count());
			}
		}
		if (i_buffer > 0)
		{
			// write buffers into RDB2 file
			if (rdbx_update)
				query_upd.next(i_buffer);
			else
				query_ins.next(i_buffer);
			i_buffer = 0;
			SG_UI_Process_Set_Progress(i_points, pPoints->Get_Count());
		}
		//transaction.commit();
	} catch (std::exception &e)
	{
		std::ostringstream ss;
		ss << "Unable to create RDB2 points! Exception: " << e.what();
		SG_UI_Msg_Add_Error(ss.str().c_str());
		return false;
	}
	catch(...) {
		SG_UI_Msg_Add_Error(CSG_String::Format(_TL("Unknown RDB2 point creation exception!")));
		return false;
	}

	try
	{
		transaction.commit();
	} catch (std::exception &e)
	{
		std::ostringstream ss;
		ss << "RDB transaction failed! Exception: " << e.what();
		SG_UI_Msg_Add_Error(ss.str().c_str());
		return false;
	}
	catch(...) {
		SG_UI_Msg_Add_Error(CSG_String::Format(_TL("Unknown RDB2 transaction exception!")));
		return false;
	}

	return true;
}
//---------------------------------------------------------
int CRDB2_Export::On_Parameter_Changed(CSG_Parameters *pParameters, CSG_Parameter *pParameter)
{
	if (!SG_STR_CMP(pParameter->Get_Identifier(), SG_T("POINTS")))		// set attribute field choices to - NOT SET -
	{
		if (pParameters->Get_Parameter("POINTS")->asPointCloud() != NULL)
		{
			int	cntFields = pParameters->Get_Parameter("POINTS")->asPointCloud()->Get_Field_Count();

			std::vector<std::string> riegl_fields;
			riegl_fields.push_back("id");
			riegl_fields.push_back("ts");
			riegl_fields.push_back("ampl");
			riegl_fields.push_back("refl");
			riegl_fields.push_back("dev");
			riegl_fields.push_back("pw");
			riegl_fields.push_back("t_idx");
			riegl_fields.push_back("t_cnt");
			riegl_fields.push_back("class");
			riegl_fields.push_back("rgba");
			for (const std::string &field : riegl_fields)
			{
				pParameters->Get_Parameter(field.c_str())->Set_Value(cntFields);
			}
		}
	}
	if (pParameters->Get_Parameter("update")->asBool())
	{
		pParameters->Get_Parameter("id")->Set_Enabled(true);
	} else
	{
		pParameters->Get_Parameter("id")->Set_Enabled(false);
	}

	return (true);
}




///////////////////////////////////////////////////////////
//														 //
//														 //
//														 //
///////////////////////////////////////////////////////////

//---------------------------------------------------------


