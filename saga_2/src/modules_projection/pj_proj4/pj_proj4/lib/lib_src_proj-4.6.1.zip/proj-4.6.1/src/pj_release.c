/* <<< Release Notice for library >>> */

#include <projects.h>

char const pj_release[]="Rel. 4.6.1, 21 August 2008";

const char *pj_get_release()

{
    return pj_release;
}
